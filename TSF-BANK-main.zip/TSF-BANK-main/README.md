#GRIPAPRIL21
The Sparks Foundation Internship program
Basic Banking System
A Website to transfer money, create account and view reords.
HTML, CSS, Bootstrap,Javascript PHP Database : MySQL are used.

Database contains two Tables- Users Table( name, email, current balance) Transaction Table record all record with time.
